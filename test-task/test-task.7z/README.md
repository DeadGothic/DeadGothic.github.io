### Проект «Test-task» ###

###
* Верстка осуществялась в рамках выполнения тестового задания от заказчика.
* Инструменты разработчика используемые при верстке:
  - Sublime Text
  - Browsers (chrome,ff,ie9+)
  - Adobe photoshop.
  - Библиотека jQuery
  - LESS
  - Bower
  - Grunt
  - Git
  - Online servise: - https://validator.w3.org
  					- https://fonts.google.com
  					- https://tinypng.com/
  					- etc.

  ###
  - Все исходники библиотеки,зависимости,мой шаблон и др. собраны в архив test.7z					


### Немного о себе ###
* Дмитрий Чеканников
* chekanni@gmail.com
* Skype:deadgothic87


