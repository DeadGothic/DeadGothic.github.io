$(document).ready(function () {
/*	$('.price-item__wrap').slick({
	infinite: true,
	dots: false,
    slidesToShow: 3,
    slidesToScroll: 3
	});*/
	$('.js-review').slick({
		speed: 1400,
		nextArrow : ".js-review__next",
		prevArrow : ".js-review__prew"
	});
});



