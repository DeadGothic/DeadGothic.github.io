$(document).ready(function () {
//scroll
$("a[href*='#header']").mPageScroll2id();
	
});