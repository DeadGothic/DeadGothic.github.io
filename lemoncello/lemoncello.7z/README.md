### Проект «lemoncello» ###

###
* Верстка осуществялась в рамках просмотра обучающего подкаста.
* Инструменты разработчика используемые при верстке:
  - LESS
  - Bower
  - Grunt
  - Sublime Text
  - Adobe photoshop,Adobe Illustrator,Inkscape
  - Browsers (chrome,ff,ie11)
  - Git 

### Немного о себе ###
* Дмитрий Чеканников
* https://vk.com/deadgothic
* Skype:deadgothic87


