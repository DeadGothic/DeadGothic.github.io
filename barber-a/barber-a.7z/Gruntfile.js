module.exports = function(grunt) {

	require("load-grunt-tasks")(grunt, { scope: "devDependencies" });

	grunt.initConfig({

		pkg: grunt.file.readJSON("package.json"),


        notify: {
          test: {
            options: {
              message: "Test",
            	}
        	}
          },

			



		less: {
			development: {
				options: {
					paths: ["less"]
				},
				files: {
					"build/css/style.css" : "less/style.less"
				}
			}
		},



		postcss: {
			options: {
				map: true,
					processors: [
						require('autoprefixer')({browsers:[
														"last 1 version",
														"Last 2 Chrome versions",
														"Last 2 Firefox versions",
														"Last 2 Opera versions",
														"Last 2 Edge versions"]}),
						require('cssnext')(),
						require("css-mqpacker")({sort:true})
						]
					},
					dist: {
						src: "build/css/*.css"
					}
				},



		cssmin: {
			options: {
				shorthandCompacting: false,
				roundingPrecision: -1
			},
			target: {
				files: {
					"build/css/style.min.css": ["build/css/style.css"]
				}
			}
		},


		htmlmin: {
			options: {
				removeComments: true,
				collapseWhitespace: true,
				collapseBooleanAttributes: true,
				caseSensitive: true,
				keepClosingSlash: false
			},
			html: {
				files: {
					"build/index.min.html": "build/index.html"
				}
			}
		},


		csscomb: {
			style: {
				expand: true,
				src: "build/**/*.css"
			}

		},


		copy: {
	 		build: {
	 			files: [{
	 				expand: true,
	 				src: [
	 					"fonts/**/*.{woff,woff2}",
	 					"img/**/**",
	 					"css/**",
	 					"fonts/**",
	 					"js/**",
	 					"*.html"
	 				],
	 				dest: "build"
	 			}]
	 		},

	 		html: {
	 			files: [{
	 				expand: true,
	 				src: [
	 					"*.html",
	 				],
	 				dest: "build"
	 			}]
	 		}
	 	},


	 	clean: {
	 		build: ["build/*" , "!build/css" ,"build/css/*", "!build/css/normalize.css"]
	 		},



     	imagemin: {
    		images: {
    			options: {
    				optimizationLevel: 3
    			},
    			files: [{
    				expand: true,
    				src: ["img/*.{png,jpg,gif}"],
    				dest: "build"
    			}]
    		}
    	},



   		svgstore: {
   			options: {
   				svg: {
   					style: "display:none"
   				}
   			},
   			symbols: {
   				files: {
   					"build/symbols.svg": ["img/icon/*.svg"]
   				}
   			}
		},



		svgmin: {
			symbols: {
				files: [{
					expand:true,
					src: ["build/img/icon/*.svg"]
				}]
			}
		},


        browserSync: {
            dev: {
                bsFiles: {
                    src : [
                        "build/css/*.css",
                        "build/*.html"
                    ]
                },
                options: {
                    watchTask: true,
                    server: "build"
                }
            }
        },

    

			watch: {
			    options: {
			        spawn: false,
			        livereload: true
			    },

			    styles: {
			        files: [
			            "less/**/*.less"
			        ],
			        tasks: [
			            "less",
			            "postcss",
			            "cssmin"
			        ]
			    },

			    html: {
			        files: [
			            "*.html"
			        ],
			        tasks: [
			            "copy:html",
			        ]
			    },

			    html2: {
			        files: [
			            "*.html"
			        ],
			        tasks: [
			            "htmlmin"
			        ]
			    }
			    },





/*	использовать когда надо заменить все пути к файлам (пример img/ на static/img)
		replace: {
				build: {
					options: {
						patterns: [{
							match: /[\"\']img\//g,
							replacement: '"/static/img/'
						},{
							match: /[\"\']css\//g,
							replacement: '"/static/css/'
						},{
							match: /[\"\']js\//g,
							replacement: '"/static/js/'
							}]
						},
						files: [{
							expand: true,
							src: ["build/css/*.css",
								  "build/*.html",
								  "build/js/*.js"
								],
							dest: "build"	
						}]
					}
				}

*/

	});

	grunt.registerTask("build" , ["clean","copy","less","postcss","cssmin","htmlmin","sumbols","imagemin","csscomb","sentryward","replace","notify"]);
	grunt.registerTask("sumbols", ["svgmin","svgstore"]);
	grunt.registerTask("sentryward" , ["browserSync","watch"]);

	

	

};


