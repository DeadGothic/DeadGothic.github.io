### Проект «Abra» ###

###
* Верстка осуществялась в рамках просмотра обучающего подкаста.
* Инструменты разработчика используемые при верстке:
  - Sublime Text
  - Browsers (chrome,ff,ie9+)
  - Adobe photoshop,Adobe Illustrator,Inkscape
  - Библиотека jQuery
  - LESS
  - Bower
  - Grunt
  - Git
  - Online servise: - https://validator.w3.org
  					- https://fonts.google.com
  					- https://www.fontsquirrel.com
  					- etc.

  ###
  - Все исходники библиотеки,зависимости,мой шаблон и др. собраны в архив abra.7z					


### Немного о себе ###
* Дмитрий Чеканников
* https://vk.com/deadgothic
* Skype:deadgothic87


